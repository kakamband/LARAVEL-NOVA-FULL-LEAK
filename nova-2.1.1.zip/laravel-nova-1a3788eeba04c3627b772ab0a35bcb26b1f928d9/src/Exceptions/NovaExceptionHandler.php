<?php

namespace Laravel\Nova\Exceptions;

use Illuminate\Foundation\Exceptions\Handler as ExceptionHandler;

class NovaExceptionHandler extends ExceptionHandler
{
}
